<?php 
require_once('Header.php');
require_once('Banner.php');
// require_once('Menu.php');
require_once('Content.php');
require_once('Footer.php');