<?php
if(! defined('BASEPATH')) exit ('a');
if($content){
	$this->load->view($content);
}
