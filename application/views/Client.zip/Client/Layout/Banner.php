    <div class="hero-area section">
      
      <!-- Backgound Image -->
      <div class="bg-image bg-parallax overlay" style="background-image:url(<?php echo base_url() ?>assets/gtc_client/img/page-background.jpg)"></div>
      <!-- /Backgound Image -->

      <div class="container">
        <div class="row">
          <div class="col-md-10 col-md-offset-1 text-center">
            <ul class="hero-area-tree">
              <li><a href="<?php echo base_url('') ?>">Home</a></li>
              <li>Courses</li>
            </ul>
            <h1 class="white-text"><?php echo $banner ?></h1>

          </div>
        </div>
      </div>

    </div>