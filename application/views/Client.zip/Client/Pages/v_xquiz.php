<div id="blog" class="section">

	<!-- container -->
	<div class="container">

		<!-- row -->
		<div class="row">

			<!-- main blog -->
			<div id="main" class="col-md-12">
				<!-- blog post -->
				<div class="blog-post">
					<div class="alert alert-success alert-dismissible">
						<h4><i class="icon fa fa-check"></i> Quiz berhasil dikirim !</h4>
						Menunggu direview oleh trainer.
					</div>
				</div>
				<!-- /blog post -->
			</div>
			<!-- /main blog -->
		</div>
		<!-- row -->
	</div>
	<!-- container -->
</div>